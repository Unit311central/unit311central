﻿# Cursor Chat History Backup

Created: 2026-08-04T15:55:08.8325682+02:00

## What this contains
- agent-transcripts/ — Agent chat transcripts per project (JSONL). This is the main readable history of Agent chats.
- conversation-search.db — Cursor conversation search index.
- .agent-data-cleanup-* — Archived agent data Cursor moved aside (if present).

## What is NOT in this zip (too large / separate)
- %APPDATA%\Cursor\User\globalStorage\state.vscdb (~20 GB) — Cursor global UI/composer state.
  Keep a separate copy of that file on an external drive if you want full Composer UI restore.
- The unit311 code folder itself — that is on GitHub (Unit311central/unit311central).

## Important
Losing Desktop\unit311 does NOT delete Cursor chats. Chats live under:
- C:\Users\Usuario\.cursor\projects\...\agent-transcripts
- C:\Users\Usuario\AppData\Roaming\Cursor\...

Losing/reimaging the laptop WOULD delete chats unless this OneDrive backup (and optionally state.vscdb) exists.

## Restore
1. Copy agent-transcripts folders back under matching project dirs in %USERPROFILE%\.cursor\projects\
2. Optionally restore conversation-search.db into AppData\Roaming\Cursor\User\globalStorage\
